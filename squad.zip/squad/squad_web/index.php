<?php include("template/cabecera.php");?>



<div class="jumbotron">
    <h1 class="display-3">4 COLORS</h1>
    <p class="lead">SOMOS UNA EMPRESA QUE LLEVA TUS IDEAS A UN GRAN FORMATO</p>
    <hr class="my-2">
    <p>More info </p>
    <p class="lead">
        <a class="btn btn-primary btn-lg" href="Jumbo action link" role="button"></a>
    </p>
</div>
<body bgcolor= #00FFFF>
    <center><img src="ima.jpg"></center>
<p align="center">ESTA PAGINA FUE CREADA 100% POR NOSOTROS NO TEMPLATE</p>

<center><div =seccion "w3-section">
      <center><b>NOMBRE</b></center>

      <input class="w3-input w3-border" type="text" required name="NOMBRE">
    </div></center>



<ol>

    <center><div =seccion "w3-section">
      <center><b>EDAD</b></center>

      <center><input class="w3-input w3-border" type="text" required name="EDAD"></center>
    </div></center>

    
</ol>

<lo>
    <center><div class="w3-section">
        <div =seccion "w3-section">
      <center><b>GENERO</b></center>

      <input class="w3-input w3-border" type="text" required name="GENERO">
    </div></center>
  </lo>


  <ol>
  <center><input type="submit" class="w3-button" w3-block w3-dark-gray name="ENVIAR"></center>
    
</body>
<?php include("template/pie.php"); ?>



