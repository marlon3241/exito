<?php include("template/cabecera.php");?>



<div class="jumbotron">
    <h1 class="display-3">4 COLORS</h1>
    <p class="lead">SOMOS UNA EMPRESA QUE LLEVA TUS IDEAS A UN GRAN FORMATO</p>
    <hr class="my-2">
    <p>More info </p>
    <p class="lead">
        <a class="btn btn-primary btn-lg" href="Jumbo action link" role="button"></a>
    </p>
</div>

<?php include("template/pie.php"); ?>



