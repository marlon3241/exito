<?php include("../template/cabecera2.php");?>
<?php

$txtID=(isset($_POST['txtID']))?$_POST['txtID']:"";
$txtNombre=(isset($_POST['txtNombre']))?$_POST['txtNombre']:"";
$txtDesc=(isset($_POST['txtDesc']))?$_POST['txtDesc']:"";
$numberPrec=(isset($_POST['numberPrec']))?$_POST['numberPrec']:"";
$txtImagen=(isset($_FILES['txtImagen']['name']))?$_FILES['txtImagen']['name']:"";
$accion=(isset($_POST['accion']))?$_POST['accion']:"";

include("../config/bd.php");

switch($accion){
case"Agregar";
     $sentenciaSQL= $conexion->prepare("INSERT INTO bebidas (nombre, descripcion, precio, imagen) VALUES (:nombre, :descripcion, :precio, :imagen);");
     $sentenciaSQL->bindParam(':nombre',$txtNombre);
     $sentenciaSQL->bindParam(':descripcion',$txtDesc);
     $sentenciaSQL->bindParam(':precio',$numberPrec);
     $sentenciaSQL->bindParam(':imagen',$txtImagen);
     $sentenciaSQL->execute();
       break;

case"Cancelar";
        echo "Presionado boton Cancelar";
        break;


case"Seleccionar";

$sentenciaSQL= $conexion->prepare("SELECT * FROM bebidas WHERE id=:id");
$sentenciaSQL->bindParam(':id',$txtID);
$sentenciaSQL->execute();
$lisbebida=$sentenciaSQL->fetch(PDO::FETCH_LAZY);

$txtNombre=$lisbebida['nombre'];
$txtDesc=$lisbebida['descripcion'];
$numberPrec=$lisbebida['precio'];
$txtImagen=$lisbebida['imagen'];

break;

case"Modificar";

$sentenciaSQL= $conexion->prepare("UPDATE bebidas SET nombre=:nombre WHERE id=:id");
$sentenciaSQL->bindParam(':nombre',$txtNombre);
$sentenciaSQL->bindParam(':id',$txtID);
$sentenciaSQL->execute();

echo "Presionando boton modificar";
break;

        
case"Borrar";
$sentenciaSQL= $conexion->prepare("DELETE  FROM bebidas WHERE id=:id");
$sentenciaSQL->bindParam(':id',$txtID);
$sentenciaSQL->execute();
       // echo "Presionado boton Borrar";
        break;


}
$sentenciaSQL= $conexion->prepare("SELECT * FROM bebidas");
$sentenciaSQL->execute();
$listaBebidas=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);


?>

<div class="col-md-5">


<div class="card">
    <div class="card-header">
        Datos de bebidas
    </div>

    <div class="card-body">

    <form method="POST" enctype="multipart/form-data">
    

<div class = "form-group">
<label for="txtID">ID:</label>
<input type="text" class="form-control" value="<?php echo $txtID; ?>" name="txtID" id="txtID" placeholder="ID">
</div>


<div class = "form-group">
<label for="txtNombre">Nombre:</label>
<input type="text" class="form-control" value="<?php echo $txtNombre;?>" name="txtNombre" id="txtNombre" placeholder="Nombre de bebida">
</div>


<div class = "form-group">
<label for="txtDesc">Descripcion:</label>
<input type="text" class="form-control" value="<?php echo $txtDesc;?>" name="txtDesc" id="txtDesc" placeholder="Descripcion de la bebida">
</div>


<div class = "form-group">
<label for="numberPrec">Precio:</label>
<input type="text" class="form-control" value="<?php echo $numberPrec;?> "name="numberPrec" id="numberPrec" placeholder="Precio del producto">
</div>


<div class = "form-group">
<label for="txtImagen">Imagen:</label>

<?php echo $txtImagen;?> 

<input type="file" class="form-control" name="txtImagen" id="txtImagen" placeholder="Nombre de bebida">
</div>


<div class="btn-group" role="group" aria-label="">
 <button type="submit" name="accion" value="Agregar" class="btn btn-success">Agregar</button>
 <button type="submit" name="accion" value="Modificar" class="btn btn-warning">Modificar</button>
 <button type="submit" name="accion" value="Cancelar" class="btn btn-info">Cancelar</button>
</div>

</form>
    </div>

  
</div>


    
    
    
    
</div>
<div class="col-md-7">
       

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>Precio</th>
                <th>Imagen</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($listaBebidas as $bebidas) { ?>


            <tr>
                <td><?php echo $bebidas['id']; ?></td>
                <td><?php echo $bebidas['nombre']; ?></td>
                <td><?php echo $bebidas['descripcion']; ?></td>
                <td><?php echo $bebidas['precio']; ?></td>
                <td><?php echo $bebidas['imagen']; ?></td>

            
                <td>

    
                <form method="post">

                <input type="hidden" name="txtID" id="txtID" value="<?php echo $bebidas['id']; ?>"/>

                <input type="submit" name="accion" value="Seleccionar" class="btn btn-primary"/>

                <input type="submit" name="accion" value="Borrar" class="btn btn-danger"/>
                  
                </td>

            </tr>
            <?php } ?>

        </tbody>
    </table>

    
</div>

<?php include("../template/pie2.php");?>